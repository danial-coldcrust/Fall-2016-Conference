package com.ppp.grade.subject.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.ppp.grade.select.persistence.SelectDAO;
import com.ppp.grade.select.persistence.SelectVO;
import com.ppp.grade.subject.persistence.SubjectDAO;
import com.ppp.grade.subject.persistence.SubjectVO;

public class SubjectController implements Controller {
	ModelAndView mav = new ModelAndView();
	int sum = 0;

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws UnsupportedEncodingException {

		String str[] = request.getParameterValues("subject");
		String num = request.getParameter("num");

		SelectVO vo = new SelectVO();
		SelectDAO selectDAO = new SelectDAO();

		/* subject number and student number inserting */
		for (int i = 0; i < str.length; i++) {

			vo.set과목코드(str[i]);
			vo.set학번(num);
			selectDAO.insertSelect(vo);
		}

		/*
		 * 1. selected table의 학번 가지고 과목을 조회해서 학점을 가져와야해 -> subject persistence있음
		 * 2. GRADUATION 의 정보를 가지고 올 수 있어야함 ->graduation persistence 없는데 3. 빼는
		 * 3. 연산 하면 됨
		 */
		
		// 1. 학점가져오기
		SubjectVO subjectVO = new SubjectVO();
		SubjectDAO subjectDAO = new SubjectDAO();
		
		List<SubjectVO> subjectList = new ArrayList<SubjectVO>();
		subjectList = subjectDAO.getSubjectWithSubjectNum(str);
		
		for(SubjectVO obj : subjectList) {
			
		 sum +=Integer.parseInt(obj.get학점()) ;
		}
	System.out.println(sum);
		mav.setViewName("result.jsp");
		return mav;
	}
}
