package com.ppp.grade.subject.persistence;

import java.util.List;

public interface SubjectService {

   public void setSubjectDAO(SubjectDAO userDAO);
   public  List<SubjectVO> getSubject(String SubjectNum);
   
}