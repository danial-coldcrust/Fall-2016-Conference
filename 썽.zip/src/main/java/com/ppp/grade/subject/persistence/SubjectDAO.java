package com.ppp.grade.subject.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ppp.grade.common.JDBCUtil;

@Repository("SubjectDAO")
public class SubjectDAO {

   private Connection conn = null;
   private PreparedStatement stmt = null;
   private ResultSet rs = null;
   private final String USER_GET = "select * from SUBJECT where 학과코드=?";
   
  
   public List<SubjectVO> getSubject(String SubjectNum){
      SubjectVO subject = null;
      List<SubjectVO> subjectList = new ArrayList<SubjectVO>();
      try{
         
         conn = JDBCUtil.getConnection();
         stmt = conn.prepareStatement(USER_GET);
         stmt.setString(1,  SubjectNum);
         
         rs = stmt.executeQuery();
         while ( rs.next()){
            subject = new SubjectVO();
            subject.set과목코드(rs.getString("과목코드"));
            subject.set과목명(rs.getString("과목명"));
            subject.set구분(rs.getString("구분"));
            subject.set학점(rs.getString("학점"));
            subject.set학년(rs.getString("학년"));
            subject.set학기(rs.getString("학기"));
            subject.set학과코드(rs.getString("학과코드"));
            subjectList.add(subject);
         }
      }catch(Exception e){
         e.printStackTrace();
      }finally{
         JDBCUtil.close(rs, stmt, conn);
      }
      return subjectList;
   }
}