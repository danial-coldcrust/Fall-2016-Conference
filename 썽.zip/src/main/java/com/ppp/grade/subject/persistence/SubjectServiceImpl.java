package com.ppp.grade.subject.persistence;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("SubjectService")
public class SubjectServiceImpl implements SubjectService {
   @Autowired
   private SubjectDAO SubjectDAO;
   
   public void setSubjectDAO(SubjectDAO subjectDAO){
      this.SubjectDAO = subjectDAO;
   }
   
   public  List<SubjectVO> getSubject(String SubjectNum){
    
      return SubjectDAO.getSubject(SubjectNum);
   }
}