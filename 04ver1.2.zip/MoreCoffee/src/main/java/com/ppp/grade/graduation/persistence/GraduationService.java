package com.ppp.grade.graduation.persistence;

import java.util.List;

public interface GraduationService {

	public GraduationVO getGraduationWithMajorNum(String MajorNum);
}