package com.ppp.grade.history.persistence;

public interface HistoryService {
	
	public void deleteHistory(HistoryVO vo);
	
}
