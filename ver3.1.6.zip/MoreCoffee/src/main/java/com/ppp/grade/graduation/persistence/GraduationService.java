package com.ppp.grade.graduation.persistence;

public interface GraduationService {

	public GraduationVO getGraduationWithMajorNum(String MajorNum);
}