package com.ppp.grade.select.persistence;

public interface SelectService {
	
	public void insertUser(SelectVO vo);
}