package com.ppp.grade.minortable.persistence;

public interface MinortableService {
	public MinortableVO getMinortableWithMinorNum(String MinorNum);
}
