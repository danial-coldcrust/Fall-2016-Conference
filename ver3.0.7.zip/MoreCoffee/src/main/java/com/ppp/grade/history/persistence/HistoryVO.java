package com.ppp.grade.history.persistence;

public class HistoryVO {
	private String 과목코드;
	private String 학번;
	
	public String get과목코드() {
		return 과목코드;
	}
	public void set과목코드(String 과목코드) {
		this.과목코드 = 과목코드;
	}
	public String get학번() {
		return 학번;
	}
	public void set학번(String 학번) {
		this.학번 = 학번;
	}
	
}
